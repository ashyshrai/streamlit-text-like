from __init__ import streamlit_text_like
import streamlit as st

r=streamlit_text_like(text='he is good',key='abc')
st.write(r)